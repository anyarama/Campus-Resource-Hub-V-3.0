"""Campus Resource Hub package initializer."""


  # Campus Resource Hub- Admin Panel

  This is a code bundle for Campus Resource Hub- Admin Panel. The original project is available at https://www.figma.com/design/4VLndFLeHq8Kitop2ywWJj/Campus-Resource-Hub--Admin-Panel.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  